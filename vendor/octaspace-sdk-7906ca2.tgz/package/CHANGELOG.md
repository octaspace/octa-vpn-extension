# Changelog

All notable changes to `@octaspace/sdk` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2026-07-06

### Added

- `http_proxy` VPN sessions: `'http_proxy'` in `VpnSubkind` and the `ProxyConfig` type.

### Changed

- `ServiceInfo.config` is typed `string | ProxyConfig`: an `http_proxy` session has a
  `{ ip, port }` object instead of a configuration string.

## [0.1.0] - 2026-07-06

### Added

- Initial release
- `OctaClient` with full resource coverage:
  - `accounts` — account details, balance, wallet generation
  - `apps` — available applications
  - `network` — network statistics (no API key needed)
  - `nodes` — list, get, pricing, reboot, binary file downloads
  - `services.mr` — Machine Rental: browse and start sessions
  - `services.render` — Render: browse and start sessions
  - `services.vpn` — VPN: browse and start sessions (WireGuard, OpenVPN, Shadowsocks, V2Ray)
  - `services.session(uuid)` — universal session lifecycle: info, logs, stop
  - `sessions` — list active and recent sessions
  - `idleJobs` — job status and auto-decoded log streaming
- Typed error hierarchy: `OctaError`, `OctaNetworkError`, `OctaTimeoutError`, `OctaApiError` and HTTP-specific subclasses
- Automatic retry with exponential backoff + full jitter for GET requests (respects `Retry-After`)
- `AbortSignal` support for per-request timeout and cancellation
- Injectable `fetch` for testing, proxying, and custom runtimes
- `onRequest` / `onResponse` hooks for logging and tracing
- Dual ESM + CJS build with TypeScript declarations
- Zero runtime dependencies

[0.1.1]: https://github.com/octaspace/js-sdk/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/octaspace/js-sdk/releases/tag/v0.1.0
